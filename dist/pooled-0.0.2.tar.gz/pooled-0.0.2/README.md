# pooled

pooled is a Python toolkit for analysis of pooled, functional genetic screens.
